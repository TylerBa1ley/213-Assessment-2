const almondIcon = L.icon({
    iconUrl: 'images/almond-icon.png', 
    iconSize: [3],  
    iconAnchor: [3, 4],          
    popupAnchor: [0, -32]             
});

const treeIcons = {
    "Almond": almondIcon,
    "English Oak": oakIcon,
    "Pin Oak": oakIcon, 
    "Maiden's Gum": L.icon({ iconUrl: 'images/gum.png', iconSize: [3] })
};